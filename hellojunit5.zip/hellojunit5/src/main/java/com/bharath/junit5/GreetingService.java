package com.bharath.junit5;

public interface GreetingService {
	String greet(String name);
}
